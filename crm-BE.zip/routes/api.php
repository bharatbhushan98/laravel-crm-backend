<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\TypeController;
use App\Http\Controllers\CustomerController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

// Auth routes
Route::prefix('auth')->group(function () {
    Route::post('/register', [AuthController::class, 'register']);
    Route::post('/login', [AuthController::class, 'login']);

    Route::middleware('auth:sanctum')->group(function () {
        Route::post('/logout', [AuthController::class, 'logout']);
        Route::get('/user', [AuthController::class, 'user']);
    });
});

// Type routes
Route::get('/types', [TypeController::class, 'index']);

Route::prefix('customers')->group(function () {
    Route::get('/', [CustomerController::class, 'index']);       // All customers
    Route::get('/{id}', [CustomerController::class, 'show']);    // Single customer by ID
    Route::post('/', [CustomerController::class, 'store']);      // Add customer
    Route::put('/{id}', [CustomerController::class, 'update']);  // Update customer
    Route::delete('/{id}', [CustomerController::class, 'destroy']); // Delete customer
});