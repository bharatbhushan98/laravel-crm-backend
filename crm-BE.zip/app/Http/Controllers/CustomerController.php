<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Customer;
use App\Models\Type;

class CustomerController extends Controller
{
    // Get all customers
    public function index()
    {
        $customers = Customer::with('type')->get();
        return response()->json($customers);
    }

    // Get single customer
    public function show($id)
    {
        $customer = Customer::with('type')->findOrFail($id);
        return response()->json($customer);
    }

    // Create customer
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'initials' => 'required',
            'contact' => 'required|email',
            'phone' => 'required',
            'type_id' => 'required|exists:types,id',
            'status' => 'required|in:Active,Inactive,Pending',
        ]);

        $customer = Customer::create($request->all());
        return response()->json($customer, 201);
    }

    // Update customer
    public function update(Request $request, $id)
    {
        $customer = Customer::findOrFail($id);

        $request->validate([
            'name' => 'required',
            'initials' => 'required',
            'contact' => 'required|email',
            'phone' => 'required',
            'type_id' => 'required|exists:types,id',
            'status' => 'required|in:Active,Inactive,Pending',
        ]);

        $customer->update($request->all());
        return response()->json($customer);
    }

    // Delete customer
    public function destroy($id)
    {
        $customer = Customer::findOrFail($id);
        $customer->delete();
        return response()->json(['message' => 'Customer deleted successfully']);
    }
}
