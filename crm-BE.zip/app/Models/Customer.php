<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'initials',
        'contact',
        'phone',
        'type_id',
        'total_orders',
        'total_amount',
        'status',
    ];

    public function type()
    {
        return $this->belongsTo(Type::class);
    }
}
